public abstract class Student {
	
	
	
     public static final double TUITION_RATE=200.0; //cost of tuition per hour
     private String name; //name of the student
     private int student_num; //student id number
     private double credit_hours; //number of credit hours taken by student
     private double gpa; //gpa of the student
 
     
     
public Student()
 {
      name="None";
  student_num=0;
  credit_hours=0;
  gpa=0;
 }
 

 public Student(String n, int s, double c, double g)
 {
      name=n;
      student_num=s;
      credit_hours=c;
      gpa=g;
 }
 
 
 
 
 public String getName() //returns student's name
 {
       return name;
 }
 
 
 public int getID() //returns student's ID Number
 {
      return student_num;
 }
 
 
 public double getHours() //returns student's Credit Hours
 {
      return credit_hours; 
 }
 
 
 public double getGpa() //returns student's gpa
 {
      return gpa;
 }
 
 
 
 
 public abstract double tuition(); //returns the tuition charged
 
 
 
}

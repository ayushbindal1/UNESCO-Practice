class Main {




  
  public static void main(String[] args) {


    
    
     System.out.print("\033[H\033[2J"); //Clears console command
     System.out.flush(); //Starts cursor at the top of the screen
     System.out.println("Grad Student Assignment"); //Write title for code
     System.out.println("Ayush Bindal 5th Period AP CS A\n\n"); //Write Name, Class Period, and Class



    
  }




  
}
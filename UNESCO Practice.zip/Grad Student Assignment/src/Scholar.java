public interface Scholar {


  
	 public final double NONE = 0;
	 public final double FULL = 100;
	 public final double HALF = 50;
	 public final double QUARTER = 25;	


	 public double Scholarship(double gpa);   
	     //returns the type of scholarship based on students gpa.
	     //lower than 2= none, 2- under 3= quarter 3-under 3.5=half
	     //3.5 and up = full.  Should be returned as a decimal
 	     //I.E. half scholarship would return 0.5  


  
}
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Scanner;


/*
ID: Ayush Bindal
LANG: JAVA
PROG: gift1 
*/


public class gift1 {

	
	
	
	public static void main(String[] args) throws IOException {
		
		
		
		 File newFile= new File("gift1.in");
		 Scanner giftScanner=new Scanner(newFile);
		 int numofpeople=giftScanner.nextInt();
		 giftScanner.nextLine();
	

		 
		 Hashtable<String, Integer> giftTable= new Hashtable<>();
		 ArrayList<String> giftList= new ArrayList<>();
		 for(int i=0; i<numofpeople; i++) {
			   String a = giftScanner.nextLine();
			   giftList.add(a);
			   giftTable.put(a,0);
		 }
		 
		 
		
		 while(giftScanner.hasNextLine()) {
			 String giftGiver=giftScanner.nextLine();
			 
			 String moneyline=giftScanner.nextLine();
			 String[] brokenline=moneyline.split(" ",2);
			 int amounttogive=Integer.parseInt(brokenline[0]);
			 int amountofpeopletogive=Integer.parseInt(brokenline[1]);

			 
			 if(amountofpeopletogive==0) {
			 
				 continue;
			 }
			 
			 
			 int amounttoreturn=amounttogive%amountofpeopletogive;
			 giftTable.put(giftGiver, (giftTable.get(giftGiver)-amounttogive+amounttoreturn));
			 
			 
			 for(int i=0; i<amountofpeopletogive; i++) {
				  String giftReciever=giftScanner.nextLine();
				  giftTable.put(giftReciever, (giftTable.get(giftReciever)+amounttogive/amountofpeopletogive));
			 }
			 
			 
		 }
		 
		 System.out.println(giftTable);
		 
		 FileWriter newWriter= new FileWriter("gift1.out");
		 
		 
		 for(int i=0; i<giftList.size(); i++)
		 {
			 Iterator iterator = giftTable.keySet().iterator();
			 while(iterator.hasNext())
			 {
				 String key = iterator.next().toString();
				 if(giftList.get(i).equals(key))
						 {
					          Integer value = giftTable.get(key);
					          newWriter.write(giftList.get(i) + " " + value+"\n");
						 }
			 }
		 }
		 
		 

		 newWriter.close();
		 

	    
	
		 
		 
	}

	
	
	
}

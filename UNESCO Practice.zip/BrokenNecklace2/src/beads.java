import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class beads {
	
	
	
	

	public static void main(String[] args) throws IOException {
		
		
		
		
		File newFile= new File("beads.txt");
		Scanner beadScanner=new Scanner(newFile);
		
		int beadlength=Integer.parseInt(beadScanner.nextLine());
		String necklace=beadScanner.nextLine();
		necklace=necklace+necklace;
        
		FileWriter newWriter= new FileWriter("beadsout.txt");
		newWriter.write(necklace);
		
		
		

	}

	
	
	
	
}

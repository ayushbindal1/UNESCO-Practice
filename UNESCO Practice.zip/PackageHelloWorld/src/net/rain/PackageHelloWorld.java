package net.rain;

public class PackageHelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Package Hello World");
	}

}

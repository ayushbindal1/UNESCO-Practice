import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
ID: Ayush Bindal
LANG: JAVA
PROG: friday
*/


public class friday {

	public static int monthDays(int year, int mon)  {
		int daysinmonth=0;
		switch(mon) {
		case 1:
			daysinmonth=31;
			break;
			  
		case 2:
				if(year%100==0) {
					if(year%400==0)
					{
						daysinmonth=29;
						return daysinmonth;
						
					}
					else {
						daysinmonth=28;
						return daysinmonth;
					}
				}
				if(year%4==0)
				{
					daysinmonth=29;
					return daysinmonth;
				}
				else {
					daysinmonth=28;
					return daysinmonth;
				}
		case 3:
			daysinmonth=31;
			break;
		case 4:
			daysinmonth=30;
			break;
		case 5:
			daysinmonth=31;
			break;
		case 6:
			daysinmonth=30;
			break;
		case 7:
			daysinmonth=31;
			break;
		case 8:
			daysinmonth=31;
			break;
		case 9:
			daysinmonth=30;
			break;
		case 10:
			daysinmonth=31;
			break;
		case 11:
			daysinmonth=30;
			break;
		case 12:
			daysinmonth=31;
			break;
		
		}
	return daysinmonth;	
	}
	
	
	
	public static void main(String[] args) throws IOException {
		
		
		
		File newFile= new File("friday.in");
		Scanner fridayScanner= new Scanner(newFile);
		int numyears=Integer.parseInt(fridayScanner.nextLine());
		int[] dayofweek= new int[7]; //Index 0-Mon,1-Tu,2-We,3-Th,4-Fr,5-Sa,6-Su
		int prevMonthDays=0;
		
		int last13th = 5; //13th Jan 1900 is Saturday
		
		
		for(int y=0; y<=numyears-1; y++)
		{
		      	 for(int mon=1; mon<=12; mon++)
		      	 {
		      		 if (!(y==0 && mon == 1)) {
		      			last13th = (last13th+prevMonthDays)%7; 
                     }
		      		dayofweek[last13th]++;
		      		 //Save the current months number of days, so that next loop can use it.
		      		 prevMonthDays = monthDays(1900+y, mon);
		      	 }
	  
		}
		
		FileWriter newWriter= new FileWriter("friday.out");
	    newWriter.write(dayofweek[5]+" "+dayofweek[6]+" "+dayofweek[0]+" "+dayofweek[1]+" "+dayofweek[2]+" "+dayofweek[3]+" "+dayofweek[4]+"\n");
		newWriter.close();
		
		
	}

	
	
	
}

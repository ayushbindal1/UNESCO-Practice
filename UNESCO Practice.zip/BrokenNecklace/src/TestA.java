
public class TestA {

	
	f=i+1;
	mismatchfound=false;
    for (f=0; f<=length-1 && mismatchfound==false, f++) {
    	index=i+f;
    	if (index>=length) index=index-length;
 
    }
    
    
    r=length+i;
    mismatchfound=false;
    for (r=0; r<=length-1 && mismatchfound=false;==false, r++) {
    	index=i-r;
    	if (index<0) index=index+length;
 
    }
    
}

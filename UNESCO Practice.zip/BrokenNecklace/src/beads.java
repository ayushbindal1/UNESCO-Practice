import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;




/*
ID: Ayush Bindal
LANG: JAVA
PROG: beads
*/




public class beads {


	
	
	public static void main(String[] args) throws IOException {
		
		
		
		File newFile= new File("beads.txt");
		Scanner beadScanner=new Scanner(newFile);
		
		int beadLength=Integer.parseInt(beadScanner.nextLine());
		String necklace=beadScanner.nextLine();
		beadScanner.close();
		
		char[] necklaceArray=new char[beadLength];
		char compareChar='s';
		int f=0, b=0, counter=0, maxvalue=0;
		boolean didNotBreak=true, didNotBreak2=true;
		
		
		
		for(int i=0; i<necklaceArray.length; i++)
		{ 
			necklaceArray[i]=necklace.charAt(i);
		}
			
		
				
		for(int i=0; i<necklaceArray.length; i++)
		{ 
			
			
			
			counter=0;
			
			
			if(necklaceArray[i]!='w')
			{ 
				compareChar=necklaceArray[i];
			}
			
			
			else if(necklaceArray[i]=='w')
			{

				
				for(int j=i; j<necklaceArray.length; j++ )
				{
					
					if(necklaceArray[j]=='r' || necklaceArray[j]=='b' )
					{
						compareChar=necklaceArray[j];
						break;
					}                                                       
					
				}

			}
			
			
			
			for(f=i; f<necklaceArray.length; f++)
			{
				
				
			   	if(necklaceArray[f]=='w' ||necklaceArray[f]==compareChar)
			   	{
			   		counter++;
			   	}
			   	
			   	if(necklaceArray[f]!='w' && necklaceArray[f]!=compareChar)
			   	{
			   		didNotBreak=false;
			   		break;
			   	}
			   	
			}
			
			
			if(didNotBreak)
			{
				
			   for(f=0; f<i; f++)
			   {
				   
				   if(necklaceArray[f]=='w' ||necklaceArray[f]==compareChar)
				   	{
				   		counter++;
				   	}
				   
				   	if(necklaceArray[f]!='w' && necklaceArray[f]!=compareChar)
				   	{
				   		break;
				   	}
				   	
			   }
			   
			}
			
			
			
			if(didNotBreak==false)
			{
				for(b=i; b>0; b--)
				{
					if(necklaceArray[b]=='w' ||necklaceArray[b]==compareChar)
				   	{
				   		counter++;
				   	}
				   
				   	if(necklaceArray[b]!='w' && necklaceArray[b]!=compareChar)
				   	{
				   		didNotBreak2=false;
				   		break;
				   	}
				}
				if(didNotBreak2)
				{
				     for(b=necklaceArray.length-1; b>f; b--)
				     {
				    		if(necklaceArray[b]=='w' ||necklaceArray[b]==compareChar)
						   	{
						   		counter++;
						   	}
						   
						   	if(necklaceArray[b]!='w' && necklaceArray[b]!=compareChar)
						   	{
						   		break;
						   	}
				     }
				}
			}
			else if (didNotBreak)
			{
				for(b=0; b>f; b--)
				{
					if(necklaceArray[b]=='w' ||necklaceArray[b]==compareChar)
				   	{
				   		counter++;
				   	}
				   
				   	if(necklaceArray[b]!='w' && necklaceArray[b]!=compareChar)
				   	{
				   		break;
				   	}
				}
			}
			
			
			
			if(counter>maxvalue) 
			{ 
				maxvalue=counter; 
			}
				
			
			
		}

		
		
		FileWriter newWriter=new FileWriter("beadsout.txt");
		newWriter.write(maxvalue+"\n");
		newWriter.close();
		
	}

	
	
	
}

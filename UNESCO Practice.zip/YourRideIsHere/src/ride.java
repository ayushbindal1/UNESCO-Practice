/*
ID: Ayush Bindal
LANG: JAVA
PROG: ride
*/


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class ride {
	
	
	

	public static void main(String[] args) throws IOException {


		
		File newFile=new File("ride.in");
		Scanner rideScanner=new Scanner(newFile);
		String cometName=rideScanner.nextLine().toUpperCase();
		String groupName=rideScanner.nextLine().toUpperCase();
		rideScanner.close();
		
		
		
		int cometnumvalue=1;
		for(int i=0; i<cometName.length(); i++)
		{
             cometnumvalue*=(cometName.charAt(i)-64);
		}
		
		
		int groupnumvalue=1;
		for(int i=0; i<groupName.length(); i++)
		{
             groupnumvalue*=(groupName.charAt(i)-64);
		}
		
		String fileContent="";
		if(cometnumvalue%47==groupnumvalue%47)
		{
			  fileContent="GO";
		}
		else
		{
			  fileContent="STAY";
		}
		
        FileWriter newWriter=new FileWriter("ride.out");
        newWriter.write(fileContent+"\n");
        newWriter.close();
		

		
	}

	

	
	
}